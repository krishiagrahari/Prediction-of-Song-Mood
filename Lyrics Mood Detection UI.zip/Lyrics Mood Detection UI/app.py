import imp
import os
from flask import Flask, redirect, render_template, request,session,send_file
from nltk.tokenize import word_tokenize
from collections import defaultdict
from nltk.corpus import wordnet as wn
from nltk.stem import WordNetLemmatizer
from nltk import pos_tag
from nltk.corpus import stopwords
import pandas as pd
import pickle
import nltk
import string
import re
from sklearn.feature_extraction.text import TfidfVectorizer


porter_stemmer = nltk.stem.porter.PorterStemmer()
def porter_tokenizer(text, stemmer=porter_stemmer):
    lower_txt = text.lower()
    tokens = nltk.wordpunct_tokenize(lower_txt)
    stems = [porter_stemmer.stem(t) for t in tokens]
    no_punct = [s for s in stems if re.match('^[a-zA-Z]+$', s) is not None]
    return no_punct

tfidf_vect = TfidfVectorizer(
            encoding='utf-8',
            decode_error='replace',
            strip_accents='unicode',
            analyzer='word',
            binary=False,
            stop_words="english",
            tokenizer=porter_tokenizer
    )


with open("all_texts", "rb") as fp:   
    all_texts = pickle.load(fp)

tfidf_vect.fit(all_texts)
claf = pickle.load(open('claf', 'rb'))


def pred(lyrics):
    wt=word_tokenize(lyrics)
    tag_map = defaultdict(lambda : wn.NOUN)
    tag_map['J'] = wn.ADJ
    tag_map['V'] = wn.VERB
    tag_map['R'] = wn.ADV
    Final_words = []
    word_Lemmatized = WordNetLemmatizer()
    for word, tag in pos_tag(wt):
        if word not in stopwords.words('english') and word.isalpha():
            word_Final = word_Lemmatized.lemmatize(word,tag_map[tag[0]])
            Final_words.append(word_Final)
    result = str(Final_words)
    df9=pd.DataFrame(columns=["lyrics"])
    df9=df9.append({'lyrics':result},ignore_index=True)
#     xvalid_count =  count_vect.transform(result)
#     res = Encoder.fit_transform(result)
    testx=df9['lyrics']
#     print(testx.shape)
    xvalid_tfidf =  tfidf_vect.transform(testx)
    y=claf.predict(xvalid_tfidf)
    print("Tag: ",end='')
    if y==0:
        return "Happy"
    elif(y==1):
    	return "Sad"
    elif(y==2):
        return "Angry"
    elif(y==3):
        return "Relaxed"



from googletrans import Translator
def pred1(lyrics):
    translator = Translator()
    l1=translator.translate(lyrics)
    #print(l1)
    lyrics=l1.text
    wt=word_tokenize(lyrics)
    tag_map = defaultdict(lambda : wn.NOUN)
    tag_map['J'] = wn.ADJ
    tag_map['V'] = wn.VERB
    tag_map['R'] = wn.ADV
    Final_words = []
    word_Lemmatized = WordNetLemmatizer()
    for word, tag in pos_tag(wt):
        if word not in stopwords.words('english') and word.isalpha():
            word_Final = word_Lemmatized.lemmatize(word,tag_map[tag[0]])
            Final_words.append(word_Final)
    result = str(Final_words)
    df9=pd.DataFrame(columns=["lyrics"])
    df9=df9.append({'lyrics':result},ignore_index=True)
#     xvalid_count =  count_vect.transform(result)
#     res = Encoder.fit_transform(result)
    testx=df9['lyrics']
#     print(testx.shape)
    xvalid_tfidf =  tfidf_vect.transform(testx)
    y=claf.predict(xvalid_tfidf)
    print("Tag: ",end='')
    if y==0:
        return "Happy"
    elif(y==1):
        return "Sad"
    elif(y==2):
        return "Angry"
    elif(y==3):
        return "Relaxed"

app = Flask(__name__)
app.secret_key= "key"




@app.route('/Hindi', methods=['POST', 'GET'])
def Hindi():
    if request.method=="POST":
        lyrics = request.form['lyrics']
        output = pred1(lyrics)
        return render_template('Hindi.html',output=output)

    return render_template('Hindi.html')


@app.route('/', methods=['POST', 'GET'])
def home():
    if request.method=="POST":
        lyrics = request.form['lyrics']
        output = pred(lyrics)
        return render_template('Home.html',output=output)

    return render_template('Home.html')

##############################

if __name__ == '__main__':
    app.run(debug=True)
